import java.awt.*;

public class Car implements Runnable {

	public static final int REDCAR = 0;
	public static final int BLUECAR = 1;
	private final static int bridgeY = 95;
	private final static int bridgeXLeft = 210;
	private final static int bridgeXLeft2 = 290;
	private final static int bridgeXMid = 410;
	private final static int bridgeXRight2 = 530;
	private final static int bridgeXRight = 610;
	private final static int totalWidth = 900;
	private final static int initX[] = { -80, totalWidth };
	private final static int initY[] = { 135, 55 };
	private final static int outLeft = -200;
	private final static int outRight = totalWidth + 200;

	int cartype;
	int xpos, ypos;
	Car inFront;
	Image image;
	TrafficController controller;

	public Car(int cartype, Car inFront, Image image, TrafficController controller) {
		
		this.cartype = cartype;
		this.inFront = inFront;
		this.image = image;
		this.controller = controller;
		
		if (cartype == REDCAR)
			xpos = inFront == null ? outRight : Math.min(initX[cartype], inFront.getX() - 90);
		else
			xpos = inFront == null ? outLeft : Math.max(initX[cartype], inFront.getX() + 90);
		
		ypos = initY[cartype];
		
	}

	public synchronized void move() {
		
		int xposOld = xpos;
		
		// red car
		if (cartype == REDCAR) { 
			if (inFront.getX() - xpos > 100) {

				xpos += 4;

				if (xpos >= bridgeXLeft & xposOld < bridgeXLeft)
					controller.enterLeft();
				
				// entrando na ponte
				else if (xpos > bridgeXLeft && xpos < bridgeXMid) {
					try {
						
						//condi��o de espera (ponte ocupada)
						while (controller.getLock() == 1 && controller.getCar() == 2 && controller.getBlue() != 0)
							wait(1000);
						
						//ponte desocupada para red car
						if (controller.getLock() == 0) {
							controller.setCar(1);
							controller.setLock(1); // ocupa ponte 
						}
		
						notify();

					} catch (InterruptedException e) {}
					
					if (ypos > bridgeY)
						ypos -= 2;

				}
				
				else if (xpos >= bridgeXRight2 && xpos < bridgeXRight) {
					
					if (ypos < initY[REDCAR])
						ypos += 2;

					if(controller.getRed() == 0)	
						controller.setLock(0);
					
				}
				
				else if (xpos >= bridgeXRight && xposOld < bridgeXRight)
					controller.leaveRight();
			}
		} 
		
		// blue car
		else { 
			if (xpos - inFront.getX() > 100) {
				xpos -= 4;
				
				if (xpos <= bridgeXRight && xposOld > bridgeXRight)
					controller.enterRight();
				
				// entrando na ponte
				else if (xpos < bridgeXRight && xpos > bridgeXMid) {
					try {
						
						//condi��o de espera (ponte ocupada)
						while (controller.getLock() == 1 && controller.getCar() == 1 && controller.getRed() != 0)
							wait(1000);
						
						//ponte desocupada para blue car
						if (controller.getLock() == 0) {
							controller.setCar(2);
							controller.setLock(1); // ocupa ponte
						}
						
						notify();

					} catch (InterruptedException e) {}
					
					if (ypos < bridgeY)
						ypos += 2;

				} 
				
				else if (xpos <= bridgeXLeft2 && xpos > bridgeXLeft) {
					
					if (ypos > initY[BLUECAR])
						ypos -= 2;

					if(controller.getBlue() == 0) 
						controller.setLock(0);
				} 
				
				else if (xpos <= bridgeXLeft && xposOld > bridgeXLeft)
					controller.leaveLeft();
			}
		}
	}

	public void run() {
		
		boolean outOfSight = cartype == REDCAR ? xpos > totalWidth : xpos < -80;
		
		// car++ (red/blue)
		if(cartype == 0) controller.setRed( controller.getRed() + 1 );
		else controller.setBlue( controller.getBlue() + 1 );
			
		while (!outOfSight) {
			move();
			outOfSight = cartype == REDCAR ? xpos > totalWidth : xpos < -80;
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {}
		}
		
		// decremento red car (saiu da tela)
		if(cartype == 0) {
			controller.setRed( controller.getRed() - 1 );
			
			if(controller.getRed() == 0) {
				controller.setLock(0); // libera ponte
				controller.setCar(0);
			}			
		}
		
		else {
			// decremento blue car (saiu da tela)
			controller.setBlue( controller.getBlue() - 1 );
			
			if(controller.getBlue() == 0) {
				controller.setLock(0); // libera ponte
				controller.setCar(0);
			}
		}
		
		xpos = cartype == REDCAR ? outRight : outLeft;
	}

	public int getX() {
		return xpos;
	}

	public void draw(Graphics g) {
		g.drawImage(image, xpos, ypos, null);
	}
}