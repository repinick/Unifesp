public class TrafficController {

	public int lock = 0; // controle ponte (critical)
	public int car;
	public int red = 0;
	public int blue = 0;
	
    public int getLock() {
		return lock;
	}
	public void setLock(int lock) {
		this.lock = lock;
	}
	public int getCar() {
		return car;
	}
	public void setCar(int car) {
		this.car = car;
	}
	public int getRed() {
		return red;
	}
	public void setRed(int red) {
		this.red = red;
	}
	public int getBlue() {
		return blue;
	}
	public void setBlue(int blue) {
		this.blue = blue;
	}
	
	public void enterLeft() {}
    public void enterRight() {}
    public void leaveLeft() {}
    public void leaveRight() {}

}